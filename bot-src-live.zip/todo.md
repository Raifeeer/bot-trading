# Todo — post-lectura carpeta ABACUS Drive

## Análisis
- [x] Mapear carpeta ABACUS en Drive (docs/drive-abacus-mapa.md)
- [x] Descargar 6 documentos prioritarios (docs/drive_abacus/)
- [x] Consolidar hallazgos (docs/conocimiento-integrado.md)

## Mejoras al bot
- [ ] strategies/options_income.py — The Wheel (CSP delta<=0.20, ROC 1-2%/mes, CC sobre asignadas, rollo)
- [ ] Filtro de earnings/news: detector de reportes (Alpaca get_company_news) + blacklist semanal
- [ ] strategies/smc.py — detector MTF cascada D→4H→M15→M1 + CHoCH + zonas S&D básicas
- [ ] config.yaml — risk_profile (conservador/moderado/agresivo) y parámetros de wheel
- [ ] Reejecutar test_alpaca_live.py completo (put spread, iron condor)
- [ ] Probar bot.py end-to-end con credenciales reales
- [ ] Actualizar README con los nuevos módulos
- [ ] Re-empaquetar zip del bot con las mejoras

## Skills
- [ ] Leer /home/ubuntu/skills/skill-creator/SKILL.md y seguir su workflow
- [ ] Crear skill "abacus-options-playbook" en /home/ubuntu/skills/ con el corpus integrado (The Wheel, CSP/CC, MTF, CHoCH, reglas de riesgo, filtros)
- [ ] Verificar skill y documentar

## Entrega
- [ ] Mensaje final con: mejoras del bot, skill creada, estado de Alpaca, recomendaciones

## Fase final — integración GCP + dashboard + Vercel
- [ ] Verificar tick completo del bot (00009-424, /diag/state muestra bot_state.json)
- [ ] Confirmar "Tick OK" en logs y datos en Firestore
- [ ] Reglas Firestore: lectura pública para el dashboard
- [ ] Firebase Web App: crear y obtener API Key
- [ ] Dashboard: VITE_FIREBASE_API_KEY y conexión en vivo verificada
- [ ] Deploy dashboard a Vercel (CLI conectada)
- [ ] Informe final con URLs y estado
