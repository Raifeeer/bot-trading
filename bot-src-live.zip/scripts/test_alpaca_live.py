"""Prueba end-to-end contra la cuenta PAPER real de Alpaca.

1. Cuenta y status
2. Cadena de opciones real (AAPL calls, expiraciones próximas)
3. Snapshots con greeks/IV de varios contratos
4. Orden DRY-RUN de un call spread (registro de cómo se enviaría)
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import date, timedelta
from options.chains import (
    OptionFeed, OptionType, select_strikes, SpreadBuilder, price_to_greeks,
)
from data.feed import MarketDataFeed


def main():
    print("=" * 70)
    print("1. CONEXIÓN Y CADENA DE OPCIONES REAL (Alpaca PAPER)")
    print("=" * 70)
    feed = OptionFeed()  # usa credenciales reales del entorno
    print("   modo simulado:", feed._sim)

    today = date.today()
    chain = feed.contracts(
        "AAPL", OptionType.CALL,
        expiration_ge=today + timedelta(days=20),
        expiration_le=today + timedelta(days=45),
        max_results=60,
    )
    print(f"   AAPL calls {today}+20d..+45d: {len(chain)} contratos")

    if not chain:
        print("   (sin contratos en esa ventana; pruebo ventana más amplia)")
        chain = feed.contracts(
            "AAPL", OptionType.CALL,
            expiration_ge=today + timedelta(days=5),
            expiration_le=today + timedelta(days=90),
            max_results=100,
        )
        print(f"   AAPL calls +5d..+90d: {len(chain)} contratos")

    print("=" * 70)
    print("2. SPOT REAL (yfinance, último cierre)")
    print("=" * 70)
    df = MarketDataFeed("yfinance").history(["AAPL"], "1d", days=3)
    spot = float(df["AAPL"].iloc[-1]["close"])
    print(f"   spot AAPL: {spot:.2f}")

    print("=" * 70)
    print("3. SNAPSHOTS CON GREEKS E IV")
    print("=" * 70)
    chain = feed.snapshots(chain, spot=spot)
    with_px = [c for c in chain if c.bid is not None or c.last is not None]
    print(f"   contratos con precio: {len(with_px)} / {len(chain)}")
    shown = 0
    for c in sorted(with_px, key=lambda c: abs(c.strike - spot))[:8]:
        print(f"   {c.symbol} K={c.strike:8.1f} bid={c.bid} ask={c.ask} "
              f"IV={c.iv if c.iv else float('nan'):.2%} delta={c.delta or float('nan'):.3f} "
              f"gamma={c.gamma or float('nan'):.4f}")
        shown += 1
    if not shown:
        print("   (snapshots sin precios — mercado cerrado u hora limitada)")

    print("=" * 70)
    print("4. SELECCIÓN DE STRIKES POR DELTA")
    print("=" * 70)
    sel = select_strikes(chain, spot, delta_target=0.35, otype=OptionType.CALL)
    print(f"   seleccionados: {[f'{c.strike}' for c in sel]}")

    print("=" * 70)
    print("5. CONSTRUCCIÓN DE CALL SPREAD (DRY-RUN)")
    print("=" * 70)
    builder = SpreadBuilder(feed)
    try:
        st = builder.vertical_spread("AAPL", spot, "bull", 0.40, 0.20)
        print(f"   {st.name}")
        print(f"   prima neta: {st.net_premium:+.2f} · riesgo máx: {st.max_risk:.2f} "
              f"· ganancia máx: {st.max_profit:.2f}")
        print(f"   break-even: {st.breakevens}")
        for l in st.legs:
            print(f"   {'COMPRAR' if l.quantity > 0 else 'VENDER'} {l.contract.symbol} "
                  f"K={l.contract.strike} prima={l.contract.mid}")
        print("\n   En ejecución real, cada pata se envía como orden LIMIT separada.\n"
              "   (Esta prueba es solo DRY-RUN: no se envía nada al mercado.)")
    except RuntimeError as e:
        print(f"   no fue posible construir el spread: {e}")


if __name__ == "__main__":
    main()
