"""Validación final de las estrategias nuevas (The Wheel y SMC) contra datos reales.

Uso: PYTHONPATH=. DATA_PROVIDER=yfinance ./venv/bin/python scripts/validate_new_strategies.py
"""
import sys
from strategies.options_income import WheelStrategy
from strategies.smc import SMCStrategy
from data.feed import MarketDataFeed
from options.chains import OptionFeed, _SimOptionFeed


def main() -> int:
    feed = MarketDataFeed("yfinance")
    errors: list[str] = []

    # --- The Wheel: CSP y CC para AAPL ---
    import os
    use_live = bool(os.environ.get("APCA_API_KEY_ID")) and feed.provider == "alpaca"
    chain_feed = OptionFeed() if use_live else _SimOptionFeed()
    wheel = WheelStrategy(chain_feed)
    spot = feed.history(["AAPL"], "1min", days=1).get("AAPL").iloc[-1]["close"]
    print(f"AAPL spot: {spot:.2f}")

    csp = wheel.csp_structure("AAPL", spot)
    if csp is None:
        errors.append("CSP no construida (sin candidatos que cumplan premium>=1%)")
        print("CSP: sin candidato hoy")
    else:
        _csp = csp.legs[0].contract
        roc_mes = (_csp.mid or 0) / _csp.strike  # prima*100 / colateral K*100
        print(f"CSP: {csp.name} strike={_csp.strike} exp={_csp.expiration} "
              f"prima=${_csp.mid:.2f} (≈{roc_mes:.1%} colateral/mes) "
              f"delta={_csp.delta if _csp.delta is not None else float('nan'):.2f} "
              f"net_premium={csp.net_premium:.2f} crédito={csp.is_credit}")
        if roc_mes < 0.01:
            errors.append("CSP prima < 1% del colateral")

    cc = wheel.cc_structure("AAPL", spot)
    if cc is None:
        errors.append("CC no construida")
        print("CC: sin candidato hoy")
    else:
        _cc = cc.legs[0].contract
        print(f"CC: {cc.name} strike={_cc.strike} prima=${_cc.mid:.2f} "
              f"delta={_cc.delta if _cc.delta is not None else float('nan'):.2f} "
              f"net_premium={cc.net_premium:.2f}")

    # --- SMC: cascada multi-timeframe para AAPL ---
    smc = SMCStrategy()
    # yfinance solo entrega 8 dias de 1m; para 15m/4h/1d pedimos más historial
    bars_15m = feed.history(["AAPL"], "15min", days=14).get("AAPL")
    print("barras 15min (14 dias):", len(bars_15m) if bars_15m is not None else 0)
    bars_1m = feed.history(["AAPL"], "1min", days=8).get("AAPL")
    print("barras 1min (8 dias):", len(bars_1m) if bars_1m is not None else 0)
    dfs = {
        "1d": None, "4h": None, "15m": None, "1m": None,
    }
    if bars_1m is not None and len(bars_1m) > 0:
        import pandas as pd
        idx = bars_1m.index.tz_localize(None)
        with_idx = bars_1m.copy()
        with_idx.index = idx
        dfs["1m"] = with_idx
        dfs["15m"] = with_idx.resample("15min").agg({
            "open": "first", "high": "max", "low": "min",
            "close": "last", "volume": "sum"}).dropna()
        dfs["4h"] = with_idx.resample("4h").agg({
            "open": "first", "high": "max", "low": "min",
            "close": "last", "volume": "sum"}).dropna()
        dfs["1d"] = with_idx.resample("1D").agg({
            "open": "first", "high": "max", "low": "min",
            "close": "last", "volume": "sum"}).dropna()
    if bars_15m is not None and len(bars_15m) > 0:
        import pandas as pd
        idx15 = bars_15m.index.tz_localize(None)
        with15 = bars_15m.copy()
        with15.index = idx15
        # completar daily/4h con el historial largo de 15m si faltan
        if dfs["4h"] is None or len(dfs["4h"]) < 40:
            dfs["4h"] = with15.resample("4h").agg({
                "open": "first", "high": "max", "low": "min",
                "close": "last", "volume": "sum"}).dropna()
        if dfs["1d"] is None or len(dfs["1d"]) < 60:
            dfs["1d"] = with15.resample("1D").agg({
                "open": "first", "high": "max", "low": "min",
                "close": "last", "volume": "sum"}).dropna()

    analysis = smc.analyze(dfs)
    print("SMC análisis:")
    for k, v in analysis.items():
        print(f"  {k}: {v}")

    signal = smc.to_signal("AAPL", analysis, spot)
    print(f"SMC señal: {signal.signal_type.value} score={signal.score:.2f}")
    print(f"SMC razón: {signal.reason}")

    print("\n" + ("VALIDACIÓN OK" if not errors else "VALIDACIÓN CON ADVERTENCIAS"))
    for e in errors:
        print("  -", e)
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
