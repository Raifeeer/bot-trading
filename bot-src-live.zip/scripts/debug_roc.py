"""Diagnóstico: roc_monthly de un put con delta -0.11 a IV 40%, T=30 días."""
from options.chains import black_scholes_price
from datetime import date

# caso K=268.44, S=305, T=30/365, iv=0.40
S, K = 305.04, 268.44
mid = black_scholes_price(S, K, 30 / 365, 0.045, 0.40, None)  # PUT
col = K * 100
roc = mid / col / 1.0
print(f"mid={mid:.2f} col={col:.0f} roc={roc:.3%}")
