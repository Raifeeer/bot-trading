"""Diagnóstico de csp_structure con datos actuales."""
from options.chains import _SimOptionFeed, OptionType, select_strikes
from strategies.options_income import roc_monthly, WheelStrategy
from datetime import date, timedelta

today = date.today()
feed = _SimOptionFeed()
chain = feed.contracts("AAPL", OptionType.PUT,
                       expiration_ge=today + timedelta(days=21),
                       expiration_le=today + timedelta(days=45))
chain = [c for c in chain if 21 <= (c.expiration - today).days <= 45]
chain = feed.snapshots(chain, 305)
roc = roc_monthly("AAPL", chain)
cands = [c for c in chain
         if c.mid > 0.10 and roc.get(c.symbol, 0) >= 0.01
         and (c.volume >= 10 or c.open_interest >= 500)]
print("candidatos:", [c.strike for c in cands])
sel = select_strikes(cands, 305, delta_target=0.20, otype=OptionType.PUT)
print("select:", [(c.strike, c.delta) for c in sel])

w = WheelStrategy(feed)
struct = w.csp_structure("AAPL", 305)
_c = struct.legs[0].contract
print(f"CSP: strike={_c.strike} delta={_c.delta:.3f} prima={_c.mid:.2f} "
      f"roc={roc.get(_c.symbol, 0):.2%}")
