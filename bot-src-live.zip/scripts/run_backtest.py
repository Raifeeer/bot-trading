"""Backtest completo: descarga datos (respaldo yfinance), corre las 3 estrategias
por timeframe y consolida métricas. Uso:
  DATA_PROVIDER=yfinance python scripts/run_backtest.py
"""
import os, sys, json, logging
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import get_config
from data.feed import MarketDataFeed
from strategies.day_trading import DayMomentum, DayBreakout
from strategies.swing_trading import SwingTrend
from engine.backtest import BacktestEngine
from engine.metrics import portfolio_metrics

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

def main():
    cfg = get_config()
    feed = MarketDataFeed(provider=os.environ.get("DATA_PROVIDER", "yfinance"))
    tickers = cfg["universo"]["tickers"]

    results = {}
    for name, StratCls in [
        ("day_momentum", DayMomentum),
        ("day_breakout", DayBreakout),
        ("swing_trend", SwingTrend),
    ]:
        if not cfg["strategies"][name]["enabled"]:
            continue
        strat_cfg = cfg["strategies"][name]
        params = strat_cfg["params"]
        tf = params.get("timeframe", strat_cfg["timeframe"])
        strat = StratCls(params)

        if tf == "1d":
            data = feed.history(tickers, "1d", days=cfg["data"]["history_days"])
        else:
            # intradía: yfinance limita ~60 días; Alpaca da más con API key
            data = feed.history(tickers, tf, days=45)

        if not data:
            print(f"[{name}] SIN DATOS — skipping")
            continue
        print(f"[{name}] datos: {len(data)} símbolos, tf={tf}")
        engine = BacktestEngine(
            {name: strat}, cfg["risk"],
            slippage_bps=cfg["execution"]["slippage_bps"],
            commission_usd=cfg["execution"]["commission_usd"],
        )
        trades, equity = engine.run(data, capital=100_000.0)
        m = portfolio_metrics(equity, trades=trades)
        results[name] = {"metrics": m, "n_trades": len(trades)}
        print(json.dumps({name: m}, indent=1, default=str))
        trades.to_csv(f"output/trades_{name}.csv", index=False)

    with open("output/backtest_results.json", "w") as f:
        json.dump(results, f, indent=1, default=str)
    print("\nResultados guardados en output/backtest_results.json")

if __name__ == "__main__":
    os.makedirs("output", exist_ok=True)
    main()
